@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0CodexConnection\Setup-CodexConnection.ps1" %*
